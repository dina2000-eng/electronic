import 'package:flutter/material.dart';

import '../../consts/my_icons.dart';
import '../../loading_manager.dart';
import '../../models/payment_method.dart';
import '../../services/assets_manager.dart';
import '../../services/utils.dart';
import '../../widgets/texts/subtitle_text.dart';
import '../../widgets/texts/title_text.dart';
import '../../widgets/go_back_widget.dart';
import '../cart/bottom_checkout.dart';
import 'orders/order_summary.dart';

class CheckoutScreen extends StatefulWidget {
  static const routeName = '/CheckoutScreen';
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String chosenPaymentMethod = paymentsMehtodsList[0].title;
  int chosenShippingMethod = 0;
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return LoadingManager(
      isLoading: isLoading,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          title: const TitlesTextWidget(
            label: "Checkout screen",
          ),
          centerTitle: false,
          leading: const GoBackWidget(),
        ),
        bottomSheet: CartBottomSheetWidget(
          buttonText: 'Purshase',
          amount: 16,
          function: () async {},
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 10),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /////Delivery Address
                Column(
                  children: [
                    Row(
                      children: [
                        const TitlesTextWidget(
                          label: 'Delivery Address',
                          fontSize: 16,
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () {},
                          child: const SubtitlesTextWidget(
                            label: "Change",
                            fontSize: 14,
                            textDecoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Row(
                      children: [
                        Image.asset(
                          AssetsManager.mapRounded,
                          height: 60,
                        ),
                        const SizedBox(
                          width: 12,
                        ),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SubtitlesTextWidget(
                              label: "addressTitle",
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                            SubtitlesTextWidget(
                              label: 'Your address',
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                          ],
                        ),
                        const Spacer(),
                        Icon(
                          AppIcons.chevron_right,
                          color: Utils(context).color,
                        )
                      ],
                    ),
                  ],
                ),

                const SizedBox(
                  height: 20,
                ),
                //////payment method/////
                const TitlesTextWidget(
                  label: 'Payment Method',
                  fontSize: 16,
                ),
                const SizedBox(
                  height: 14,
                ),

                const SizedBox(
                  height: 14,
                ),

                const SizedBox(
                  height: 16,
                ),

                //////order Summary//////
                const OrderSummaryWidget(
                  subtotal: "17",
                ),

                const SizedBox(
                  height: 20,
                ),
                const Divider(),

                const SizedBox(
                  height: kBottomNavigationBarHeight + 10,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
