import 'package:flutter/material.dart';

import '../../../../widgets/go_back_widget.dart';
import '../../../../widgets/texts/title_text.dart';
import 'orders_widget.dart';

class OrdersScreenFree extends StatelessWidget {
  static const routeName = '/OrdersScreenFree';

  const OrdersScreenFree({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const TitlesTextWidget(label: 'Orders (14)'),
        leading: const GoBackWidget(),
      ),
      body: ListView.builder(
        itemCount: 12,
        itemBuilder: (BuildContext ctx, int index) {
          return const OrdersWidgetFree();
        },
      ),
    );
  }
}
