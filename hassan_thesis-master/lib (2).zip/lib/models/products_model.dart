
import 'package:flutter/material.dart';

class ProductModel with ChangeNotifier {
  final int id;
  final String name;
  final String description;
  final double price;
  final int instock;
  final String image;
  final String publish;
  final int categoryId;
  final int userId;
  final String createdAt;
  final String updatedAt;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.instock,
    required this.image,
    required this.publish,
    required this.categoryId,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) {
    // log("json['id'] ${json['id']}");
    // log("json['price'] ${json['price']}");
    return ProductModel(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      price: double.parse(json['price'].toString()),
      instock: json['instock'],
      image: json['image'],
      publish: json['publish'],
      categoryId: json['category_id'],
      userId: json['user_id'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
    );
  }
}
