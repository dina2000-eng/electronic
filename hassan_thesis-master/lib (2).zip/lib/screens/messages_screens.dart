import 'package:electronics_market/widgets/texts/subtitle_text.dart';
import 'package:electronics_market/widgets/texts/title_text.dart';
import 'package:flutter/material.dart';

import '../services/assets_manager.dart';
import '../widgets/app_name_text.dart';
import '../widgets/profile_image.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: const AppNameTextWidget(
          fontSize: 18,
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 15, top: 5, bottom: 5),
          child: Image.asset(
            AssetsManager.shoppingCart,
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(child: ListView.builder(itemBuilder: (context, index) {
            return const ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 3, horizontal: 10),
              leading: ProfileImageWidget(radius: 18),
              title: TitlesTextWidget(label: "Name"),
              subtitle: SubtitlesTextWidget(label: "Text message"),
              trailing: Icon(
                Icons.arrow_forward_ios_rounded,
                size: 20,
              ),
            );
          }))
        ],
      ),
    );
  }
}
