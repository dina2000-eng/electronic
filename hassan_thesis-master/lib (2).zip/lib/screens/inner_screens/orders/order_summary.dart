import 'package:flutter/material.dart';
import '../../../widgets/texts/subtitle_text.dart';

class OrderSummaryWidget extends StatelessWidget {
  const OrderSummaryWidget({
    Key? key,
    required this.subtotal,
  }) : super(key: key);
  final String subtotal;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 20,
        ),
        const SubtitlesTextWidget(
          label: 'Order Summary',
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
        const SizedBox(
          height: 16,
        ),
        const Row(
          children: [
            SubtitlesTextWidget(
              label: 'Subtotal',
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            Spacer(),
            Icon(
              Icons.payments,
              color: Colors.green,
            ),
            SizedBox(
              width: 8,
            ),
            SubtitlesTextWidget(
              label: '\$ 16.0',
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ],
        ),
        const SizedBox(
          height: 12,
        ),
        const Row(
          children: [
            SubtitlesTextWidget(
              label: 'Tax',
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            Spacer(),
            SubtitlesTextWidget(
              label: '\$0.00',
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ],
        ),
        const SizedBox(
          height: 16,
        ),
        const Divider(),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            const SubtitlesTextWidget(
              label: 'Total Price',
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            const Spacer(),
            SubtitlesTextWidget(
              label: '\$$subtotal',
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ],
        ),
      ],
    );
  }
}
